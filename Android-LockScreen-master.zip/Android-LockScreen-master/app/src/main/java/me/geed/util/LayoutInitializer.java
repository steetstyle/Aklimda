package me.geed.util;

import android.content.Context;
import android.content.ContextWrapper;
import android.support.v7.app.AppCompatActivity;

public class LayoutInitializer {

    private Context context;
    private AppCompatActivity activity;

    public LayoutInitializer(Context applicationContext) {
        context = applicationContext;
        activity = getActivity(applicationContext);

    }

    public AppCompatActivity getActivity() {
        return activity;
    }

    public Context getContext() {
        return context;
    }


    public AppCompatActivity getActivity(Context context)
    {
        if (context == null)
        {
            return null;
        }
        else if (context instanceof ContextWrapper)
        {
            if (context instanceof AppCompatActivity)
            {
                return (AppCompatActivity) context;
            }
            else
            {
                return getActivity(((ContextWrapper) context).getBaseContext());
            }
        }

        return null;
    }

    public boolean isActivityNull(){
        return getActivity() != null;
    }




}
