package me.geed.util;

import android.view.View;
import android.view.ViewGroup;

public class ViewUtil {

    public static void addItemToView(ViewGroup viewGroup, View view) {
        viewGroup.addView(view);
    }
}
